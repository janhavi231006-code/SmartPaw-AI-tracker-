import 'package:flutter/material.dart';
import 'screens/login.dart';
import 'screens/map.dart';
import 'screens/vaccinations.dart';

void main() {
  runApp(const SmartPawApp());
}

class SmartPawApp extends StatelessWidget {
  const SmartPawApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Paw AI Tracker',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/map': (context) => const MapScreen(),
        '/vaccinations': (context) => const VaccinationsScreen(),
      },
    );
  }
}
