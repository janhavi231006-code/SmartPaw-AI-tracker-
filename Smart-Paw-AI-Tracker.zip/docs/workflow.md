# Project Workflow (High-Level)

1. **Collar (ESP32)** collects basic telemetry and posts to `/api/dogs`.
2. **Backend (Express)** stores data (in memory for now).
3. **App (Flutter)** displays login, map, and vaccination screens.
4. **AI Model (Python)**: placeholder CNN for dog classification.
