const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let dogs = [];

app.get('/api/dogs', (req, res) => {
  res.json(dogs);
});

app.post('/api/dogs', (req, res) => {
  const dog = req.body;
  dogs.push(dog);
  res.status(201).json(dog);
});

app.listen(3000, () => {
  console.log('Backend running on http://localhost:3000');
});
