# 🐾 Smart Paw AI Tracker

AI + IoT powered platform for tracking and managing stray dog vaccination, health, and location via smart collar bands and a cross-platform mobile app.
